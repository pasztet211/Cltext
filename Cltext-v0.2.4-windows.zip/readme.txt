Cltext v0.2.3
=============

1. Put these files in C:\Cltext
2. Add C:\Cltext to your PATH
3. Create a .clt file
4. Run:
   cltext filename.clt

Optional:
Install the VS Code extension from the main Cltext repository.

For full documentation, see the Cltext GitHub README.\